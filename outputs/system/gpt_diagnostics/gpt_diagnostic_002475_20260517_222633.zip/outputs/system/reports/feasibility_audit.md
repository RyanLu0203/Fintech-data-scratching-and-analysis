# Program Feasibility and Data Quality Audit

- Audit mode: `dry_run`
- Existing local data only: `True`
- Allow fetch missing data: `True`
- Requested date range: `2024-01-01` to `2026-04-30`
- Cross-stock status: `NOT_RELIABLE`
- Final recommendation: **Not reliable without more data**

## Usable Stocks

- No stock is currently fully usable.

## Missing Or Unusable Artifacts

- `002475`: sentiment_data, ablation_metrics, portfolio_curves, trading_logs

## Common Overlap

- Common start date: `2024-01-02`
- Common end date: `2026-04-30`
- Common overlap trading days: `562`

## Warnings

- `002475` `sentiment_score_missing_rate` = `1.0`: Missing sentiment values before conservative zero fallback.
- `002475` `sentiment_coverage_ratio` = `0.0`: Trading days with news_count > 0 divided by trading days.
- `002475` `metrics_nan_rate` = `1.0`: NaN rate in numeric ablation metric cells.
- `002475` `portfolio_curves_flat_or_identical` = `True`: True means curves are missing, flat, or all strategies are indistinguishable.

## Interpretation

This audit distinguishes missing sentiment from neutral sentiment: a zero sentiment score only counts as news coverage when `news_count > 0`. Dry-run mode does not fetch data or rerun DQN training. Full-run mode can use the existing pipeline to fetch and recompute missing artifacts only when explicitly enabled.

Cross-stock analysis should not be treated as reliable when portfolio curves are missing, ablation metrics are mostly empty, RL state rows are too few, or sentiment coverage is dominated by no-news days.