# Market-Impact Cross-Stock Discussion

This cross-stock view preserves the peer-sentiment baseline and adds two peer market-impact DQN groups.
- Targets summarized: 1
- Best NLP type counts: impact=0, sentiment=0, none=1

A positive market-impact result means the peer future-return-labelled text signal improved DQN performance relative to the same DQN without NLP. Interpret results only when reliability checks pass.