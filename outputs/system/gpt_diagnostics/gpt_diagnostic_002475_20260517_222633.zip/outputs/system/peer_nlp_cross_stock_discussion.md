# Peer NLP Cross-Stock Discussion

This section uses the official peer-sector NLP transfer design. No stock is used to train its own NLP scorer.
- Targets summarized: 1
- Reliable targets: 1
- Sector-peer NLP improves count: 1
- Marketwide-peer NLP improves count: 1

NLP transfer should be interpreted cautiously. A positive effect is only meaningful when corpus sufficiency, sentiment coverage, non-flat DQN curves, and test-trade checks pass.