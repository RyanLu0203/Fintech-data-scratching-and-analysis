# Peer-Sector NLP Transfer Result

- Target stock: `002475`
- Official experiment: `peer_sector_nlp_transfer`
- Legacy stock-level NLP: deprecated and excluded from main results.
- DQN training window: `2025-01-27` to `2025-10-29`
- DQN testing window: `2025-10-30` to `2026-04-30`
- Sector NLP effect label: `NLP improves`
- Marketwide NLP effect label: `NLP improves`
- Reliability status: `READY_FOR_SUBMISSION`
- Reason if not reliable: ``

The target stock is held out from both peer corpora. Sentiment scores are lagged by one trading day before DQN action selection.