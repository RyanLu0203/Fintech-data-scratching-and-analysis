# Peer Market-Impact NLP Result

- Target stock: `002475`
- Official default experiment: no-NLP control, sector sentiment, and sector impact.
- Optional add-on: marketwide sentiment and marketwide impact peer benchmark groups.
- DQN group order: no-NLP, sector sentiment, sector impact, marketwide sentiment, marketwide impact.
- DQN training window: `2025-01-27` to `2025-10-29`
- DQN testing window: `2025-10-30` to `2026-04-30`
- Best strategy: `buy_and_hold`
- Best NLP type: `none`
- Sector impact label: `Inconclusive`
- Marketwide impact label: `Inconclusive`
- Reliability status: `READY_FOR_PRESENTATION`

Market-impact NLP is trained on peer news labelled by peer stocks' post-news future returns. The target stock is held out from NLP training labels. Buy-and-hold is a benchmark, not one of the DQN experiment groups.